# Créditos das fotos

Fotos enviadas pelo dono do projeto. A origem, o autor e a licença de cada uma **não foram informados**.
Antes de publicar o site, confirme que você pode usá-las e preencha os créditos abaixo.

- `especies/coelhos.jpg` – origem: ? – autor: ? – licença: ?
- `especies/caes.jpg` – origem: ? – autor: ? – licença: ?
- `especies/gatos.jpg` – origem: ? – autor: ? – licença: ?
- `especies/bettas.jpg` – origem: ? – autor: ? – licença: ?
- `especies/agapornis.jpg` – origem: ? – autor: ? – licença: ?
- `grupos/caes-e-gatos.jpg` – montagem de uma foto de cachorro (origem: ?) com `especies/gatos.jpg` – autor: ? – licença: ?
- `grupos/pequenos-mamiferos.jpg` – recorte da foto de `especies/coelhos.jpg` (origem: ?)
- `grupos/aves.jpg` – recorte da foto de `especies/agapornis.jpg` (origem: ?)
- `grupos/peixes.jpg` – recorte da foto de `especies/bettas.jpg` (origem: ?)
- `hero.jpg` – colagem das fotos de coelho, cachorro, gato, betta e agapornis (origens acima)
- `especies/porquinhos-da-india.jpg` – origem: ? – autor: ? – licença: ? (porquinho-da-índia sem pelo, raça "skinny pig")
- `especies/ratos-twister.jpg` – origem: ? – autor: ? – licença: ? (rato de estimação sem pelo)
- `especies/calopsitas.jpg` – origem: ? – autor: ? – licença: ? (recorte sem a legenda de texto)
- `especies/periquitos-australianos.jpg` – origem: ? – autor: ? – licença: ?
