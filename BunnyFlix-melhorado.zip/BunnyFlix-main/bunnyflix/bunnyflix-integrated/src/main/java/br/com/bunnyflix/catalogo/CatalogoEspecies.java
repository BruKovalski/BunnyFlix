package br.com.bunnyflix.catalogo;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Catálogo fixo das espécies exibidas na loja. O campo {@code especie} de cada
 * produto deve usar exatamente o nome cadastrado aqui.
 */
public final class CatalogoEspecies {

    public static final String GRUPO_MAMIFEROS = "Pequenos Mamíferos";
    public static final String GRUPO_CAES_GATOS = "Cães e Gatos";
    public static final String GRUPO_AVES = "Aves";
    public static final String GRUPO_PEIXES = "Peixes";

    private static final List<Especie> TODAS = List.of(
        // Pequenos mamíferos
        new Especie("Coelhos", GRUPO_MAMIFEROS, "🐰", "#c4895b", "Oryctolagus cuniculus",
            "Herbívoros de digestão delicada: o feno deve ser a base da dieta e ficar sempre à disposição."),
        new Especie("Porquinhos-da-Índia", GRUPO_MAMIFEROS, "🐾", "#d9a441", "Cavia porcellus",
            "Não produzem vitamina C e precisam recebê-la todos os dias pela alimentação. São animais sociáveis."),
        new Especie("Hamsters", GRUPO_MAMIFEROS, "🐹", "#e0813b", "Mesocricetus auratus (hamster-sírio) e outras espécies",
            "Têm hábitos noturnos e percorrem longas distâncias durante a noite, por isso a roda precisa ser grande e silenciosa."),
        new Especie("Chinchilas", GRUPO_MAMIFEROS, "🐾", "#7a8ba3", "Chinchilla lanigera",
            "Originárias dos Andes, têm uma pelagem muito densa e tomam banho de pó, nunca de água. Sofrem com o calor."),
        new Especie("Gerbils", GRUPO_MAMIFEROS, "🐾", "#9c7b4c", "Meriones unguiculatus",
            "Vêm de regiões áridas da Mongólia e da China, adoram escavar e precisam de uma camada profunda de substrato."),
        new Especie("Ratos Twister", GRUPO_MAMIFEROS, "🐀", "#8d7b9b", "Rattus norvegicus (forma domesticada)",
            "Inteligentes e sociáveis, gostam de escalar, explorar e viver em grupo."),
        new Especie("Camundongos", GRUPO_MAMIFEROS, "🐁", "#8e9aa5", "Mus musculus",
            "Pequenos e muito ativos, gostam de esconderijos, túneis e de roer."),

        // Cães e gatos
        new Especie("Cães", GRUPO_CAES_GATOS, "🐶", "#3f8fbf", "Canis lupus familiaris",
            "Companheiros do ser humano há milhares de anos, precisam de exercício, convívio e alimentação adequada ao porte e à idade."),
        new Especie("Gatos", GRUPO_CAES_GATOS, "🐱", "#cf6a8a", "Felis catus",
            "Carnívoros estritos, precisam de ração formulada para a espécie, além de arranhadores e lugares altos para explorar."),

        // Aves
        new Especie("Calopsitas", GRUPO_AVES, "🦜", "#e2c13f", "Nymphicus hollandicus",
            "Originárias da Austrália, usam a crista para expressar emoções e precisam de convívio e de brinquedos para roer."),
        new Especie("Periquitos-australianos", GRUPO_AVES, "🦜", "#43b581", "Melopsittacus undulatus",
            "Pequenos e sociáveis, também vêm da Austrália e vivem melhor com estímulos e companhia."),
        new Especie("Agapornis", GRUPO_AVES, "🦜", "#e0585a", "Agapornis spp. (ex.: Agapornis roseicollis)",
            "Conhecidos como inseparáveis, são aves de origem africana, muito sociáveis e ativas."),
        new Especie("Canários", GRUPO_AVES, "🐦", "#f0b429", "Serinus canaria",
            "Originários das ilhas Canárias, da Madeira e dos Açores, são famosos pelo canto dos machos."),

        // Peixes
        new Especie("Bettas", GRUPO_PEIXES, "🐟", "#7b4fd1", "Betta splendens",
            "Originários do Sudeste Asiático, respiram ar na superfície e os machos costumam brigar entre si."),
        new Especie("Kinguios", GRUPO_PEIXES, "🐠", "#ef7d2a", "Carassius auratus",
            "Descendem de carpas criadas na China, crescem bastante e produzem muita sujeira, por isso pedem aquário grande e boa filtragem."),
        new Especie("Guppies", GRUPO_PEIXES, "🐠", "#2ab7a9", "Poecilia reticulata",
            "Peixes vivíparos de origem sul-americana: os filhotes nascem já nadando."),
        new Especie("Neons", GRUPO_PEIXES, "🐟", "#2f7de1", "Paracheirodon innesi",
            "Peixes de cardume originários da bacia amazônica, vivem melhor em grupo.")
    );

    private static final Map<String, Especie> POR_NOME = TODAS.stream()
        .collect(Collectors.toMap(Especie::getNome, e -> e, (a, b) -> a, LinkedHashMap::new));

    private static final Map<String, List<Especie>> POR_GRUPO = TODAS.stream()
        .collect(Collectors.groupingBy(Especie::getGrupo, LinkedHashMap::new, Collectors.toList()));

    private CatalogoEspecies() {}

    public static List<Especie> todas() {
        return TODAS;
    }

    public static Map<String, Especie> porNome() {
        return Collections.unmodifiableMap(POR_NOME);
    }

    public static Map<String, List<Especie>> porGrupo() {
        return Collections.unmodifiableMap(POR_GRUPO);
    }

    public static Especie buscar(String nome) {
        return nome == null ? null : POR_NOME.get(nome);
    }
}
