package br.com.bunnyflix.catalogo;

import br.com.bunnyflix.model.Produto;

import java.util.List;

/** Seção horizontal (carrossel) da página inicial: uma categoria de produtos. */
public class Prateleira {

    private final String titulo;
    private final String icone;
    private final List<Produto> produtos;

    public Prateleira(String titulo, String icone, List<Produto> produtos) {
        this.titulo = titulo;
        this.icone = icone;
        this.produtos = produtos;
    }

    public String getTitulo() { return titulo; }
    public String getIcone() { return icone; }
    public List<Produto> getProdutos() { return produtos; }
}
