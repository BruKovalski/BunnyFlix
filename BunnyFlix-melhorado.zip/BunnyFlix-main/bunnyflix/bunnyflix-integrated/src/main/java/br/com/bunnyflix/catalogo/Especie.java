package br.com.bunnyflix.catalogo;

/**
 * Espécie de pet atendida pela loja. Não é uma entidade do banco: os dados
 * ficam em {@link CatalogoEspecies} e servem para filtros, ícones e cores.
 */
public class Especie {

    private final String nome;
    private final String grupo;
    private final String emoji;
    private final String cor;
    private final String cientifico;
    private final String curiosidade;

    public Especie(String nome, String grupo, String emoji, String cor, String cientifico, String curiosidade) {
        this.nome = nome;
        this.grupo = grupo;
        this.emoji = emoji;
        this.cor = cor;
        this.cientifico = cientifico;
        this.curiosidade = curiosidade;
    }

    public String getNome() { return nome; }
    public String getGrupo() { return grupo; }
    public String getEmoji() { return emoji; }
    public String getCor() { return cor; }
    public String getCientifico() { return cientifico; }
    public String getCuriosidade() { return curiosidade; }
}
