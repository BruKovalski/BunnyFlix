package br.com.bunnyflix.controller;

import br.com.bunnyflix.catalogo.CatalogoEspecies;
import br.com.bunnyflix.catalogo.Especie;
import br.com.bunnyflix.catalogo.Prateleira;
import br.com.bunnyflix.model.Produto;
import br.com.bunnyflix.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.text.Normalizer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Controller
public class HomeController {

    /** Produto exibido no banner principal da página inicial. */
    private static final String TITULO_DESTAQUE = "Feno Premium de Timóteo";

    /** Categoria cadastrada no banco, título da prateleira e ícone Font Awesome. */
    private static final String[][] CATEGORIAS = {
        {"Alimentos",  "Alimentação e Nutrição Premium",  "fa-utensils"},
        {"Gaiolas",    "Habitats, Gaiolas e Tocas",       "fa-house"},
        {"Brinquedos", "Brinquedos e Enriquecimento",     "fa-puzzle-piece"},
        {"Acessórios", "Acessórios do Dia a Dia",         "fa-toolbox"},
        {"Higiene",    "Higiene e Cuidados",              "fa-pump-soap"}
    };

    @Autowired
    private ProdutoService produtoService;

    @GetMapping("/")
    public String index(Model model,
                        @RequestParam(required = false) String especie,
                        @RequestParam(required = false) String q) {

        String filtroEspecie = limpar(especie);
        String busca = limpar(q);

        List<Produto> produtos = filtroEspecie != null
            ? produtoService.buscarPorEspecie(filtroEspecie)
            : intercalarPorEspecie(produtoService.listarTodos());

        if (busca != null) {
            String termo = normalizar(busca);
            produtos = produtos.stream()
                .filter(p -> normalizar(textoPesquisavel(p)).contains(termo))
                .toList();
        }

        List<Prateleira> prateleiras = new ArrayList<>();
        for (String[] categoria : CATEGORIAS) {
            List<Produto> daCategoria = produtos.stream()
                .filter(p -> categoria[0].equals(p.getCategoria()))
                .toList();
            if (!daCategoria.isEmpty()) {
                prateleiras.add(new Prateleira(categoria[1], categoria[2], daCategoria));
            }
        }

        Especie especieInfo = CatalogoEspecies.buscar(filtroEspecie);

        model.addAttribute("tituloPagina", montarTitulo(filtroEspecie, busca));
        model.addAttribute("prateleiras", prateleiras);
        model.addAttribute("totalProdutos", produtos.size());
        model.addAttribute("todasEspecies", CatalogoEspecies.todas());
        model.addAttribute("especiesPorGrupo", CatalogoEspecies.porGrupo());
        model.addAttribute("mapaEspecies", CatalogoEspecies.porNome());
        model.addAttribute("especieSelecionada", filtroEspecie);
        model.addAttribute("especieInfo", especieInfo);
        model.addAttribute("busca", busca);
        model.addAttribute("destaque", produtoService.buscarPorTitulo(TITULO_DESTAQUE).orElse(null));

        return "index";
    }

    private static String limpar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpo = valor.trim();
        return limpo.isEmpty() ? null : limpo;
    }

    private static String montarTitulo(String especie, String busca) {
        if (busca != null) {
            return "Busca por “" + busca + "” – BunnyFlix";
        }
        if (especie != null) {
            return especie + " – BunnyFlix";
        }
        return "BunnyFlix – Tudo para o seu pet, no estilo streaming";
    }

    private static String textoPesquisavel(Produto p) {
        Especie e = CatalogoEspecies.buscar(p.getEspecie());
        return String.join(" ",
            nulo(p.getTitulo()), nulo(p.getCategoria()), nulo(p.getEspecie()),
            nulo(p.getDescricao()), e != null ? nulo(e.getCientifico()) : "");
    }

    private static String nulo(String texto) {
        return texto == null ? "" : texto;
    }

    private static String normalizar(String texto) {
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
            .replaceAll("\\p{M}", "")
            .toLowerCase(Locale.ROOT);
    }

    /**
     * Alterna as espécies na ordem dos produtos, para que cada carrossel da página
     * inicial mostre variedade logo nos primeiros cartões.
     */
    private static List<Produto> intercalarPorEspecie(List<Produto> produtos) {
        Map<String, Deque<Produto>> filas = new LinkedHashMap<>();
        for (Produto p : produtos) {
            filas.computeIfAbsent(String.valueOf(p.getEspecie()), chave -> new ArrayDeque<>()).add(p);
        }
        List<Produto> resultado = new ArrayList<>(produtos.size());
        while (resultado.size() < produtos.size()) {
            for (Deque<Produto> fila : filas.values()) {
                Produto p = fila.poll();
                if (p != null) {
                    resultado.add(p);
                }
            }
        }
        return resultado;
    }
}
