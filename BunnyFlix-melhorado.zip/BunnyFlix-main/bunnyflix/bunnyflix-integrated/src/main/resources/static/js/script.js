/* BunnyFlix – carrinho, janela de detalhes e carrosséis */
(function () {
  'use strict';

  var STORAGE_KEY = 'bunnyflix.carrinho';
  var moeda = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  var cart = carregarCarrinho();
  var ultimoFoco = null;

  /* ---------- utilidades ---------- */
  function $(id) {
    return document.getElementById(id);
  }

  function carregarCarrinho() {
    try {
      var salvo = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return Array.isArray(salvo) ? salvo : [];
    } catch (e) {
      return [];
    }
  }

  function salvarCarrinho() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    } catch (e) {
      /* armazenamento indisponível: o carrinho continua funcionando na página */
    }
  }

  function criar(tag, classe, texto) {
    var el = document.createElement(tag);
    if (classe) { el.className = classe; }
    if (texto !== undefined) { el.textContent = texto; }
    return el;
  }

  function lerProduto(origem) {
    var d = origem.dataset;
    return {
      id: Number(d.id),
      titulo: d.titulo || '',
      categoria: d.categoria || '',
      especie: d.especie || '',
      preco: parseFloat(d.preco) || 0,
      avaliacao: parseFloat(d.avaliacao),
      medida: d.medida || '',
      imagem: d.imagem || '',
      emoji: d.emoji || '🐾',
      cor: d.cor || '#5b6b7a',
      descricao: d.descricao || ''
    };
  }

  function mostrarAviso(mensagem) {
    var toast = $('toast');
    toast.textContent = mensagem;
    toast.classList.add('show');
    clearTimeout(mostrarAviso.timer);
    mostrarAviso.timer = setTimeout(function () { toast.classList.remove('show'); }, 2800);
  }

  /* ---------- carrinho ---------- */
  function adicionar(produto) {
    var existente = cart.find(function (item) { return item.id === produto.id; });
    if (existente) {
      existente.qty += 1;
    } else {
      cart.push({
        id: produto.id,
        titulo: produto.titulo,
        preco: produto.preco,
        imagem: produto.imagem,
        emoji: produto.emoji,
        cor: produto.cor,
        qty: 1
      });
    }
    atualizarCarrinho();
    mostrarAviso('Adicionado ao carrinho: ' + produto.titulo);
  }

  function alterarQuantidade(id, delta) {
    var item = cart.find(function (i) { return i.id === id; });
    if (!item) { return; }
    item.qty += delta;
    if (item.qty <= 0) {
      remover(id);
      return;
    }
    atualizarCarrinho();
  }

  function remover(id) {
    cart = cart.filter(function (item) { return item.id !== id; });
    atualizarCarrinho();
  }

  function atualizarCarrinho() {
    salvarCarrinho();

    var container = $('cartItems');
    var total = 0;
    var quantidade = 0;
    container.textContent = '';

    if (cart.length === 0) {
      container.appendChild(criar('p', 'cart-empty', 'Seu carrinho está vazio.'));
    }

    cart.forEach(function (item) {
      total += item.preco * item.qty;
      quantidade += item.qty;

      var linha = criar('div', 'cart-item');

      var miniatura = criar('div', 'cart-thumb');
      miniatura.style.background = item.cor;
      miniatura.appendChild(criar('span', null, item.emoji));
      if (item.imagem) {
        var img = document.createElement('img');
        img.src = item.imagem;
        img.alt = '';
        img.onerror = function () { img.remove(); };
        miniatura.appendChild(img);
      }
      linha.appendChild(miniatura);

      var info = criar('div', 'cart-item-info');
      info.appendChild(criar('p', 'cart-item-title', item.titulo));
      info.appendChild(criar('p', 'cart-item-price', moeda.format(item.preco * item.qty)));

      var qtd = criar('div', 'qty');
      var menos = criar('button', null, '−');
      menos.type = 'button';
      menos.dataset.action = 'qty-minus';
      menos.dataset.id = item.id;
      menos.setAttribute('aria-label', 'Diminuir a quantidade de ' + item.titulo);
      var mais = criar('button', null, '+');
      mais.type = 'button';
      mais.dataset.action = 'qty-plus';
      mais.dataset.id = item.id;
      mais.setAttribute('aria-label', 'Aumentar a quantidade de ' + item.titulo);
      qtd.appendChild(menos);
      qtd.appendChild(criar('span', null, String(item.qty)));
      qtd.appendChild(mais);
      info.appendChild(qtd);
      linha.appendChild(info);

      var lixeira = criar('button', 'remove-btn');
      lixeira.type = 'button';
      lixeira.dataset.action = 'remove';
      lixeira.dataset.id = item.id;
      lixeira.setAttribute('aria-label', 'Remover ' + item.titulo + ' do carrinho');
      lixeira.appendChild(criar('i', 'fa-solid fa-trash'));
      linha.appendChild(lixeira);

      container.appendChild(linha);
    });

    $('cartBadge').textContent = quantidade;
    $('cartTotal').textContent = moeda.format(total);
  }

  function abrirCarrinho(abrir) {
    var gaveta = $('cartDrawer');
    var deveAbrir = typeof abrir === 'boolean' ? abrir : !gaveta.classList.contains('active');
    gaveta.classList.toggle('active', deveAbrir);
    gaveta.setAttribute('aria-hidden', String(!deveAbrir));
    $('overlay').hidden = !deveAbrir;
    $('cartBtn').setAttribute('aria-label', deveAbrir ? 'Fechar o carrinho' : 'Abrir o carrinho');
    if (deveAbrir) {
      ultimoFoco = document.activeElement;
      gaveta.querySelector('.close-modal').focus();
    } else if (ultimoFoco) {
      ultimoFoco.focus();
    }
  }

  function finalizarPedido() {
    if (cart.length === 0) {
      mostrarAviso('Seu carrinho está vazio!');
      return;
    }
    cart = [];
    atualizarCarrinho();
    abrirCarrinho(false);
    mostrarAviso('Pedido realizado com sucesso! Aproveite a experiência BunnyFlix 🐰🍿');
  }

  /* ---------- janela de detalhes ---------- */
  function abrirDetalhes(produto) {
    $('modalTitle').textContent = produto.titulo;
    $('modalCategoria').textContent = produto.categoria;
    $('modalEspecie').textContent = produto.especie;
    $('modalRating').textContent = isNaN(produto.avaliacao)
      ? '–'
      : produto.avaliacao.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' de avaliação';
    $('modalMedida').textContent = produto.medida;
    $('modalDesc').textContent = produto.descricao;
    $('modalPreco').textContent = moeda.format(produto.preco);
    $('modalEmoji').textContent = produto.emoji;
    $('modalHero').style.background =
      'linear-gradient(135deg, ' + produto.cor + ', #1c1c1c)';

    var img = $('modalImg');
    if (produto.imagem) {
      img.hidden = false;
      img.alt = produto.titulo;
      img.onerror = function () { img.hidden = true; };
      img.src = produto.imagem;
    } else {
      img.hidden = true;
      img.removeAttribute('src');
      img.alt = '';
    }

    $('modalBuyBtn').onclick = function () {
      adicionar(produto);
      fecharDetalhes();
    };

    ultimoFoco = document.activeElement;
    var modal = $('modal');
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    modal.querySelector('.close-modal').focus();
  }

  function fecharDetalhes() {
    var modal = $('modal');
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    if (ultimoFoco) { ultimoFoco.focus(); }
  }

  /* ---------- menus suspensos ---------- */
  function fecharMenus(exceto) {
    document.querySelectorAll('.dropdown.open').forEach(function (item) {
      if (item !== exceto) {
        item.classList.remove('open');
        item.querySelector('.dropdown-toggle').setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- eventos ---------- */
  document.addEventListener('click', function (evento) {
    var alvo = evento.target;

    var toggle = alvo.closest('.dropdown-toggle');
    if (toggle) {
      var item = toggle.parentElement;
      var abrir = !item.classList.contains('open');
      fecharMenus(item);
      item.classList.toggle('open', abrir);
      toggle.setAttribute('aria-expanded', String(abrir));
      return;
    }
    fecharMenus(null);

    if (alvo === $('modal')) {
      fecharDetalhes();
      return;
    }
    if (alvo === $('overlay')) {
      abrirCarrinho(false);
      return;
    }

    var botao = alvo.closest('[data-action]');
    if (botao) {
      var acao = botao.dataset.action;
      var dono = botao.closest('[data-id]');

      switch (acao) {
        case 'add':
          if (dono) { adicionar(lerProduto(dono)); }
          break;
        case 'details':
          if (dono) { abrirDetalhes(lerProduto(dono)); }
          break;
        case 'close-modal':
          fecharDetalhes();
          break;
        case 'toggle-cart':
          abrirCarrinho();
          break;
        case 'checkout':
          finalizarPedido();
          break;
        case 'qty-plus':
          alterarQuantidade(Number(botao.dataset.id), 1);
          break;
        case 'qty-minus':
          alterarQuantidade(Number(botao.dataset.id), -1);
          break;
        case 'remove':
          remover(Number(botao.dataset.id));
          break;
        case 'scroll-prev':
        case 'scroll-next':
          var trilho = botao.parentElement.querySelector('.carousel-track');
          var direcao = acao === 'scroll-next' ? 1 : -1;
          trilho.scrollBy({ left: direcao * trilho.clientWidth * 0.85, behavior: 'smooth' });
          break;
        default:
          break;
      }
      return;
    }

    /* clique em qualquer parte do cartão abre os detalhes */
    var cartao = alvo.closest('.product-card');
    if (cartao) {
      abrirDetalhes(lerProduto(cartao));
    }
  });

  document.addEventListener('keydown', function (evento) {
    if (evento.key !== 'Escape') { return; }
    fecharMenus(null);
    if ($('modal').classList.contains('active')) {
      fecharDetalhes();
    } else if ($('cartDrawer').classList.contains('active')) {
      abrirCarrinho(false);
    }
  });

  window.addEventListener('scroll', function () {
    $('navbar').classList.toggle('scrolled', window.scrollY > 50);
  }, { passive: true });

  /* ---------- início ---------- */
  $('navbar').classList.toggle('scrolled', window.scrollY > 50);
  atualizarCarrinho();
})();
