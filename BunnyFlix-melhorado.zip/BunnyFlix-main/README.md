# BunnyFlix

Loja pet no estilo streaming, feita com Spring Boot, Thymeleaf e banco H2 em memória.
Tem login da área do Grêmio, com registro de acessos no banco.

## Como executar

Requisitos: Java 17 ou superior e Maven.

```bash
cd bunnyflix/bunnyflix-integrated
mvn spring-boot:run
```

Depois acesse <http://localhost:8080>.

- Console do banco H2: <http://localhost:8080/h2-console> (URL `jdbc:h2:mem:bunnyflixdb`, usuário `sa`, senha em branco)
- Login de teste: usuário `tricolor`, senha `1903`

## O que a loja oferece

- **17 espécies** em 4 grupos: Pequenos Mamíferos, Cães e Gatos, Aves e Peixes
- **5 categorias** de produto: Alimentos, Gaiolas (habitats), Brinquedos, Acessórios e Higiene
- Busca por produto, espécie, categoria ou nome científico (sem diferenciar acentos)
- Filtro por espécie, com nome científico e uma curiosidade sobre o animal
- Carrinho que continua salvo ao recarregar a página

## Como adicionar uma espécie ou um produto

1. **Espécie nova:** inclua uma linha em `catalogo/CatalogoEspecies.java` (nome, grupo, emoji, cor, nome científico e curiosidade).
2. **Produto novo:** inclua uma linha em `DataLoader.java`, usando exatamente o nome da espécie cadastrado no passo anterior.
3. **Foto (opcional):** o último campo do produto (`imagemUrl`) aceita o endereço de uma imagem. Sem foto, o cartão mostra a arte da espécie.

> Os preços e as avaliações do catálogo são valores ilustrativos.
