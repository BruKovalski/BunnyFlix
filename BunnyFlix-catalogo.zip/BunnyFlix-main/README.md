# BunnyFlix

Catálogo online de produtos pet (somente consulta), feito com Spring Boot 3, Thymeleaf e banco H2 em memória.
Não existe carrinho, pedido nem pagamento. O catálogo é público; o login da área do Grêmio continua existindo,
com registro de acessos no banco, e não altera o catálogo.

## Como executar

Requisitos: Java 17+ e Maven.

```bash
cd bunnyflix/bunnyflix-integrated
mvn spring-boot:run
```

Abra http://localhost:8080

## Páginas

| Rota | Conteúdo |
|------|----------|
| `/` | Página inicial: banner, setores, espécies, tipos de produto, seleção da loja |
| `/catalogo` | Todos os produtos, com busca, filtros, ordenação e paginação |
| `/grupo/{slug}` | Setor (cães e gatos, pequenos mamíferos, aves, peixes) |
| `/especie/{slug}` | Uma espécie (ex.: `/especie/coelhos`) |
| `/produto/{id}-{slug}` | Página do produto |
| `/sobre`, `/contato` | Páginas institucionais |
| `/login` | Área do Grêmio (inalterada) |
| `/sitemap.xml`, `/robots.txt` | SEO |

Filtros disponíveis (combináveis): busca por texto (sem distinguir acentos), tipo de produto, faixa de preço e
ordenação (nome, menor preço, maior preço). Os filtros usam apenas dados que existem no banco.

## Compras desativadas

* Nenhum botão, página ou script de carrinho, checkout ou pagamento existe na interface.
* O projeto nunca teve rotas de pedido no servidor (o carrinho antigo ficava só no navegador). Mesmo assim,
  os caminhos `/carrinho`, `/checkout`, `/pedido(s)`, `/pagamento(s)` e `/api/...` equivalentes respondem
  `410 Gone` para qualquer método (`BloqueioComprasController`).

## Fotografias reais (pendente: precisam ser adicionadas por você)

O código está pronto para exibir fotos, mas **o projeto não traz nenhuma fotografia**. Enquanto não houver arquivo,
as páginas mostram um ícone sobre cor neutra. Coloque fotos próprias (ou com licença de uso) em
`src/main/resources/static/img/` com estes nomes (`.jpg`, `.jpeg`, `.png` ou `.webp`) e reinicie a aplicação:

* `hero.jpg` – foto do banner da página inicial
* `grupos/caes-e-gatos`, `grupos/pequenos-mamiferos`, `grupos/aves`, `grupos/peixes`
* `especies/` + `coelhos`, `porquinhos-da-india`, `hamsters`, `chinchilas`, `gerbils`, `ratos-twister`,
  `camundongos`, `caes`, `gatos`, `calopsitas`, `periquitos-australianos`, `agapornis`, `canarios`, `bettas`,
  `kinguios`, `guppies`, `neons`

Fotos de produtos: preencha o campo `imagemUrl` do produto (em `DataLoader` ou no banco). Use a foto do próprio
produto, não a de um animal. Recomenda-se redimensionar as imagens (cerca de 800 px de largura) antes de enviar.

## Dados da loja

Edite o bloco `loja.*` em `src/main/resources/application.properties` (e-mail, telefone, endereço, horário,
Instagram). Campos vazios não são exibidos; a página Contato só mostra o que estiver preenchido.

## Observações

* Produtos, preços e descrições em `DataLoader` são de demonstração. As avaliações (estrelas) foram retiradas
  da interface por serem valores inventados; a coluna continua no banco.
* O banco H2 é em memória: os dados voltam ao estado inicial a cada reinicialização.
* O console do H2 e o log de SQL vêm desativados. Reative só em desenvolvimento local.
* Pendência de segurança na área do Grêmio: as senhas ainda são gravadas em texto puro e a página de login exibe
  um usuário de teste. Antes de publicar, troque por senhas com hash e remova essa dica.
