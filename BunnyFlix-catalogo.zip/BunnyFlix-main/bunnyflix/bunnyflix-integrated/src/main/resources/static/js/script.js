/* BunnyFlix – menu móvel e painel de filtros */
(function () {
  'use strict';

  function configurarAlternador(botao, alvo) {
    if (!botao || !alvo) { return; }

    function definir(aberto) {
      alvo.classList.toggle('open', aberto);
      botao.setAttribute('aria-expanded', String(aberto));
    }

    botao.addEventListener('click', function () {
      definir(botao.getAttribute('aria-expanded') !== 'true');
    });

    document.addEventListener('keydown', function (evento) {
      if (evento.key === 'Escape' && botao.getAttribute('aria-expanded') === 'true') {
        definir(false);
        botao.focus();
      }
    });
  }

  configurarAlternador(document.getElementById('menuBtn'), document.getElementById('menuPrincipal'));
  configurarAlternador(document.getElementById('filtrosBtn'), document.getElementById('filtros'));
})();
