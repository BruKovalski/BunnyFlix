package br.com.bunnyflix.config;

import br.com.bunnyflix.catalogo.CatalogoEspecies;
import br.com.bunnyflix.catalogo.Especie;
import br.com.bunnyflix.catalogo.GrupoEspecies;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Localiza as fotografias reais colocadas em {@code static/img}. Só devolve um caminho quando o
 * arquivo existe, então a página nunca tenta carregar imagem inexistente.
 * Nomes esperados: img/hero.jpg, img/grupos/{slug}.jpg e img/especies/{slug}.jpg
 * (também são aceitos .jpeg, .png e .webp). Reinicie a aplicação depois de adicionar fotos.
 */
@Component("fotos")
public class FotosService {

    private static final String[] EXTENSOES = {"jpg", "jpeg", "webp", "png"};

    private final Map<String, String> caminhos = new HashMap<>();

    @PostConstruct
    void carregar() {
        registrar("hero");
        for (GrupoEspecies g : CatalogoEspecies.grupos()) {
            registrar("grupos/" + g.getSlug());
        }
        for (Especie e : CatalogoEspecies.todas()) {
            registrar("especies/" + e.getSlug());
        }
    }

    private void registrar(String base) {
        for (String ext : EXTENSOES) {
            if (new ClassPathResource("static/img/" + base + "." + ext).exists()) {
                caminhos.put(base, "/img/" + base + "." + ext);
                return;
            }
        }
    }

    public String hero() { return caminhos.get("hero"); }
    public String grupo(String slug) { return caminhos.get("grupos/" + slug); }
    public String especie(String slug) { return caminhos.get("especies/" + slug); }
}
